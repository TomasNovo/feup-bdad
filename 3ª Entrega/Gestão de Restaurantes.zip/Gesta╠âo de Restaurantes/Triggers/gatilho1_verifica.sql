INSERT INTO Pessoa (idPessoa, nome, NIF, nacionalidade) VALUES (20, 'Nuno', 123456780, 'Portugal');
INSERT INTO Pessoa (idPessoa, nome, NIF, nacionalidade) VALUES (1, 'Amadeu', 123456789, 'Portugal');
INSERT INTO Pessoa (idPessoa, nome, NIF, nacionalidade) VALUES (20, 'Tomas', 023456789, 'Portugal');