INSERT INTO Sala (idSala, nome, responsavel) VALUES (4, 'Nascente', 16);
INSERT INTO Sala (idSala, nome, responsavel) VALUES (5, 'Magnum', 18);
INSERT INTO Sala (idSala, nome, responsavel) VALUES (6, 'Tommy', 19);

SELECT *
FROM Sala;
.print Nao adiciona sala "Tommy" nem "Magnum"